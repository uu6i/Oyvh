# VAMPS MUSIC — Android source project

This archive contains the Android project source only. It intentionally does **not** contain a GitHub Actions workflow YAML file.

## Project layout

- `settings.gradle.kts` — Gradle project settings
- `build.gradle.kts` — Android/Kotlin plugin versions
- `gradle.properties` — AndroidX and Gradle settings
- `gradle/wrapper/gradle-wrapper.properties` — Gradle 8.13 distribution
- `app/` — Android application source, manifest, resources and dependencies

## Build requirements

- JDK 17
- Android SDK with API 36 platform and build tools installed
- Gradle 8.13

From the project root, run:

```bash
gradle --no-daemon :app:assembleDebug
```

The debug APK is produced at:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Create your own workflow at `.github/workflows/android-apk.yml` in your repository. Configure it to install JDK 17, Android SDK and Gradle 8.13, then run `gradle --no-daemon :app:assembleDebug` from the repository root and upload `app/build/outputs/apk/debug/app-debug.apk`.

## Current implementation scope

Implemented in this source: Compose app shell, Obsidian theme, adaptive five-tab layout, local MediaStore audio scanning, Media3 playback service, mini-player, full player controls, local search, liked-track UI state, queue display, provider app handoff cards and sleep timer.

Not yet implemented: provider OAuth integrations, cross-service search, persistent playlists/history, synchronized lyrics, full equalizer UI, crossfade engine, dedicated Cast integration and smart recommendation backend. Provider cards do not claim accounts are connected.

## Build diagnostic note

The previously supplied screenshots showed a Kotlin compilation exception but did not include the first compiler diagnostic (`e: ...` with the source filename and line number). This source refresh removes the workflow file and replaces one potentially unavailable Material icon reference. A successful build still needs to be confirmed by running the build; no APK is included or claimed as compiled.
